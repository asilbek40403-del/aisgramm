// Простое файловое хранилище на JSON.
// Для продакшена замените на PostgreSQL/MongoDB — структура data ниже
// один в один ложится на таблицы users / chats / user_chat_meta / messages.

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, 'data.json');

let data = { users: [], chats: [], userChatMeta: [], messages: [], stories: [] };

// Учётные данные владельца берутся из переменных окружения — задайте их
// в .env перед первым запуском (см. .env.example / README).
const OWNER_PHONE = process.env.OWNER_PHONE || '+10000000000';
const OWNER_INITIAL_PASSWORD = process.env.OWNER_PASSWORD || 'changeme123';

function load() {
  if (fs.existsSync(DB_PATH)) {
    try {
      data = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
    } catch (e) {
      console.error('Ошибка чтения базы данных, стартуем с чистой:', e.message);
    }
  }
  data.users = data.users || [];
  data.chats = data.chats || [];
  data.userChatMeta = data.userChatMeta || [];
  data.messages = data.messages || [];
  data.stories = data.stories || []; // истории (сторис) — фото/видео, живут 24 часа

  // Создаём аккаунт владельца при первом запуске, если его ещё нет.
  // Только владелец может выдавать Premium и NFT-бейджи другим пользователям.
  const ownerExists = data.users.some((u) => u.isOwner);
  if (!ownerExists) {
    const { v4: uuidv4 } = require('uuid');
    const user = {
      id: uuidv4(),
      phone: OWNER_PHONE,
      username: null,
      displayName: 'Владелец',
      passwordHash: bcrypt.hashSync(OWNER_INITIAL_PASSWORD, 10),
      avatarColor: '#4dabf7',
      avatarUrl: null,
      bio: '',
      premium: true,
      nft: null,
      isOwner: true,
      phoneVerified: true,
      createdAt: Date.now(),
    };
    data.users.push(user);
    console.log('👑 Создан аккаунт владельца.');
    console.log(`   Телефон: ${OWNER_PHONE}`);
    console.log(`   Пароль:  ${OWNER_INITIAL_PASSWORD}  (смените его сразу после первого входа!)`);
    saveNow();
  }
}

function saveNow() {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

let saveTimeout = null;
function save() {
  clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  }, 150);
}

load();

module.exports = { data, save };

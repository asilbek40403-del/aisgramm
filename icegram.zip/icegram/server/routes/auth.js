const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { data, save } = require('../db');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

const COLORS = ['#e17076', '#7bc862', '#65aadd', '#a695e7', '#ee7aae', '#6ec9cb', '#faa774', '#4dabf7'];
function randomColor() {
  return COLORS[Math.floor(Math.random() * COLORS.length)];
}

function publicUser(u) {
  return {
    id: u.id,
    phone: u.phone,
    displayName: u.displayName,
    avatarColor: u.avatarColor,
    avatarUrl: u.avatarUrl || null,
    bio: u.bio || '',
    premium: !!u.premium,
    // Коллекционный "NFT"-бейдж аватара — демо-фича без блокчейна: назначается
    // только владельцем аккаунта через админ-панель.
    nft: u.nft || null,
    isOwner: !!u.isOwner,
  };
}

function normalizePhone(raw) {
  const digits = String(raw || '').replace(/[^\d+]/g, '');
  return digits;
}

// ============================================================
// Отправка SMS-кода подтверждения.
//
// ВАЖНО: в этой сборке нет доступа к реальному SMS-провайдеру
// (Twilio, SMS.ru, SMSC.ru и т.п.), поэтому код не отправляется
// на настоящий телефон — он логируется на сервере и возвращается
// в ответе ТОЛЬКО потому что сервер работает в демо-режиме
// (DEMO_SMS=true). Перед тем как выкладывать проект в продакшен,
// подключите реального SMS-провайдера в функции sendSms() ниже и
// уберите поле devCode из ответа.
// ============================================================
const pendingCodes = new Map(); // phone -> { code, expiresAt, attempts }
const CODE_TTL_MS = 5 * 60 * 1000;
const DEMO_SMS = process.env.DEMO_SMS !== 'false';

function generateCode() {
  return String(Math.floor(1000 + Math.random() * 9000)); // 4 цифры, как в Telegram
}

async function sendSms(phone, code) {
  // Точка подключения реального SMS-шлюза, например:
  //
  // await fetch('https://sms-provider.example/send', {
  //   method: 'POST',
  //   headers: { Authorization: `Bearer ${process.env.SMS_API_KEY}` },
  //   body: JSON.stringify({ to: phone, text: `АйсГрам: ваш код ${code}` }),
  // });
  console.log(`📩 [ДЕМО-SMS] Код подтверждения для ${phone}: ${code}`);
}

router.post('/send-code', async (req, res) => {
  const phone = normalizePhone(req.body && req.body.phone);
  if (!phone || phone.replace('+', '').length < 6) {
    return res.status(400).json({ error: 'Введите корректный номер телефона' });
  }
  const code = generateCode();
  pendingCodes.set(phone, { code, expiresAt: Date.now() + CODE_TTL_MS, attempts: 0 });
  await sendSms(phone, code);

  const isNewUser = !data.users.find((u) => u.phone === phone);
  const resp = { ok: true, isNewUser };
  if (DEMO_SMS) {
    // Демо-режим: реального SMS-провайдера не подключено, поэтому код
    // показывается прямо в ответе/консоли, чтобы форму можно было протестировать.
    resp.devCode = code;
    resp.devNote = 'Демо-режим: реальный SMS-провайдер не подключён, код выведен для теста.';
  }
  res.json(resp);
});

router.post('/verify-code', async (req, res) => {
  const phone = normalizePhone(req.body && req.body.phone);
  const { code, displayName, password } = req.body || {};
  if (!phone || !code) return res.status(400).json({ error: 'Телефон и код обязательны' });

  const entry = pendingCodes.get(phone);
  if (!entry) return res.status(400).json({ error: 'Сначала запросите код подтверждения' });
  if (Date.now() > entry.expiresAt) {
    pendingCodes.delete(phone);
    return res.status(400).json({ error: 'Код истёк, запросите новый' });
  }
  entry.attempts += 1;
  if (entry.attempts > 5) {
    pendingCodes.delete(phone);
    return res.status(429).json({ error: 'Слишком много попыток, запросите новый код' });
  }
  if (entry.code !== String(code)) {
    return res.status(401).json({ error: 'Неверный код подтверждения' });
  }
  pendingCodes.delete(phone);

  let user = data.users.find((u) => u.phone === phone);
  if (!user) {
    // Регистрация нового пользователя после подтверждения телефона
    if (!password || String(password).length < 4) {
      return res.status(400).json({ error: 'Придумайте пароль (минимум 4 символа) для входа в настройках' });
    }
    const passwordHash = await bcrypt.hash(String(password), 10);
    user = {
      id: uuidv4(),
      phone,
      username: null,
      displayName: (displayName && displayName.trim()) || phone,
      passwordHash,
      avatarColor: randomColor(),
      avatarUrl: null,
      bio: '',
      premium: false,
      nft: null,
      isOwner: false,
      phoneVerified: true,
      createdAt: Date.now(),
    };
    data.users.push(user);

    // Автоматически создаём "Избранное" — приватное облачное хранилище (чат с самим собой)
    const savedChat = {
      id: uuidv4(),
      type: 'saved',
      title: 'Избранное',
      members: [user.id],
      createdAt: Date.now(),
    };
    data.chats.push(savedChat);
    data.userChatMeta.push({ userId: user.id, chatId: savedChat.id, folder: 'all', pinned: true, archived: false });
    save();
  }

  const token = jwt.sign({ id: user.id, phone: user.phone }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: publicUser(user) });
});

// Вход владельца по телефону + паролю (в обход SMS — владелец не проходит
// через демо-код подтверждения).
router.post('/owner-login', async (req, res) => {
  const phone = normalizePhone(req.body && req.body.phone);
  const { password } = req.body || {};
  const user = data.users.find((u) => u.phone === phone && u.isOwner);
  if (!user) return res.status(401).json({ error: 'Неверный телефон или пароль' });
  const ok = await bcrypt.compare(String(password || ''), user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Неверный телефон или пароль' });
  const token = jwt.sign({ id: user.id, phone: user.phone }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, user: publicUser(user) });
});

router.get('/users', (req, res) => {
  // список пользователей для быстрого создания чата (демо-функция)
  res.json(data.users.map(publicUser));
});

function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'Нет токена авторизации' });
  const token = header.replace('Bearer ', '');
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.userId = payload.id;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Токен недействителен' });
  }
}

function ownerMiddleware(req, res, next) {
  const u = data.users.find((x) => x.id === req.userId);
  if (!u || !u.isOwner) return res.status(403).json({ error: 'Доступно только владельцу' });
  next();
}

// Готовые пресеты коллекционных "NFT"-бейджей для аватара (демо, без блокчейна)
const NFT_PRESETS = [
  { id: 'plush-pepe', name: 'Plush Pepe', emoji: '🐸', ring: 'linear-gradient(135deg,#7bc862,#2f8f3d)' },
  { id: 'golden-star', name: 'Golden Star', emoji: '⭐', ring: 'linear-gradient(135deg,#ffd76a,#c8722f)' },
  { id: 'diamond-ring', name: 'Diamond Ring', emoji: '💎', ring: 'linear-gradient(135deg,#8ad7ff,#4dabf7)' },
  { id: 'santa-hat', name: 'Santa Hat', emoji: '🎅', ring: 'linear-gradient(135deg,#ff8a8a,#b1493a)' },
  { id: 'crystal-ball', name: 'Crystal Ball', emoji: '🔮', ring: 'linear-gradient(135deg,#c9a6ff,#a695e7)' },
  { id: 'lol-pop', name: 'Lol Pop', emoji: '🍭', ring: 'linear-gradient(135deg,#ee7aae,#e17076)' },
];
router.get('/nft-presets', (req, res) => res.json(NFT_PRESETS));

router.get('/me', authMiddleware, (req, res) => {
  const u = data.users.find((x) => x.id === req.userId);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  res.json(publicUser(u));
});

// Обновление профиля: имя, био, своя аватарка (URL от /api/upload)
router.patch('/profile', authMiddleware, (req, res) => {
  const u = data.users.find((x) => x.id === req.userId);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  const { displayName, avatarUrl, bio } = req.body || {};
  if (typeof displayName === 'string' && displayName.trim()) u.displayName = displayName.trim();
  if (typeof avatarUrl === 'string') u.avatarUrl = avatarUrl || null;
  if (typeof bio === 'string') u.bio = bio.slice(0, 200);
  save();
  res.json(publicUser(u));
});

// Смена пароля пользователем: нужен текущий пароль
router.post('/change-password', authMiddleware, async (req, res) => {
  const u = data.users.find((x) => x.id === req.userId);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  const { oldPassword, newPassword } = req.body || {};
  if (!newPassword || String(newPassword).length < 4) {
    return res.status(400).json({ error: 'Новый пароль должен быть не короче 4 символов' });
  }
  const ok = await bcrypt.compare(String(oldPassword || ''), u.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Текущий пароль указан неверно' });
  u.passwordHash = await bcrypt.hash(String(newPassword), 10);
  save();
  res.json({ ok: true });
});

// ================== Админ-панель владельца ==================
// Только владелец может выдавать Premium и NFT-бейджи другим пользователям.

router.get('/admin/users', authMiddleware, ownerMiddleware, (req, res) => {
  res.json(data.users.map(publicUser));
});

router.post('/admin/users/:id/premium', authMiddleware, ownerMiddleware, (req, res) => {
  const u = data.users.find((x) => x.id === req.params.id);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  u.premium = !!(req.body && req.body.enable);
  save();
  res.json(publicUser(u));
});

router.post('/admin/users/:id/nft', authMiddleware, ownerMiddleware, (req, res) => {
  const u = data.users.find((x) => x.id === req.params.id);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  const { presetId } = req.body || {};
  if (!presetId) {
    u.nft = null;
  } else {
    const preset = NFT_PRESETS.find((p) => p.id === presetId);
    if (!preset) return res.status(400).json({ error: 'Неизвестный NFT-пресет' });
    u.nft = preset;
  }
  save();
  res.json(publicUser(u));
});

module.exports = { router, authMiddleware, ownerMiddleware, JWT_SECRET, publicUser };

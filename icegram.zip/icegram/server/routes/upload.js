const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { authMiddleware } = require('./auth');

const router = express.Router();
router.use(authMiddleware);

// По умолчанию 2 ГБ — как в обычном Telegram (для Premium-режима 4 ГБ
// достаточно поднять переменную окружения MAX_UPLOAD_MB=4000)
const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 2000);

const storage = multer.diskStorage({
  destination: path.join(__dirname, '..', 'uploads'),
  filename: (req, file, cb) => cb(null, uuidv4() + path.extname(file.originalname || '')),
});

const upload = multer({ storage, limits: { fileSize: MAX_MB * 1024 * 1024 } });

router.post('/', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Файл не получен' });
  res.json({
    url: '/uploads/' + req.file.filename,
    name: req.file.originalname,
    size: req.file.size,
    mime: req.file.mimetype,
  });
});

// Обработка ошибки превышения размера файла
router.use((err, req, res, next) => {
  if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: `Файл больше лимита в ${MAX_MB} МБ` });
  }
  next(err);
});

module.exports = router;

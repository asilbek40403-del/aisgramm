// Истории (Stories) — короткие фото/видео-статусы, которые "сгорают" через 24 часа,
// как в Telegram/Instagram. Хранятся в общей data.stories.
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { data, save } = require('../db');
const { authMiddleware, publicUser } = require('./auth');

const router = express.Router();
router.use(authMiddleware);

const DAY_MS = 24 * 60 * 60 * 1000;

// Создать историю: { type: 'photo'|'video', fileUrl, caption }
router.post('/', (req, res) => {
  const { type, fileUrl, caption } = req.body || {};
  if (!fileUrl || (type !== 'photo' && type !== 'video')) {
    return res.status(400).json({ error: 'Нужны type (photo/video) и fileUrl' });
  }
  const story = {
    id: uuidv4(),
    userId: req.userId,
    type,
    fileUrl,
    caption: (caption || '').slice(0, 200),
    createdAt: Date.now(),
    expiresAt: Date.now() + DAY_MS,
    viewedBy: [],
  };
  data.stories.push(story);
  save();
  res.json(story);
});

// Список активных историй, сгруппированный по авторам
router.get('/', (req, res) => {
  const now = Date.now();
  const active = data.stories.filter((s) => s.expiresAt > now);

  const byUser = new Map();
  active.forEach((s) => {
    if (!byUser.has(s.userId)) byUser.set(s.userId, []);
    byUser.get(s.userId).push(s);
  });

  const result = [];
  byUser.forEach((stories, userId) => {
    const u = data.users.find((x) => x.id === userId);
    if (!u) return;
    stories.sort((a, b) => a.createdAt - b.createdAt);
    result.push({
      user: publicUser(u),
      stories: stories.map((s) => ({
        id: s.id,
        type: s.type,
        fileUrl: s.fileUrl,
        caption: s.caption,
        createdAt: s.createdAt,
        expiresAt: s.expiresAt,
        viewsCount: s.viewedBy.length,
        viewedByMe: s.viewedBy.includes(req.userId),
        mine: s.userId === req.userId,
      })),
      allViewed: stories.every((s) => s.viewedBy.includes(req.userId) || s.userId === req.userId),
    });
  });

  // Сначала непросмотренные, "моя" история — всегда первая
  result.sort((a, b) => {
    if (a.user.id === req.userId) return -1;
    if (b.user.id === req.userId) return 1;
    return Number(a.allViewed) - Number(b.allViewed);
  });

  res.json(result);
});

router.post('/:id/view', (req, res) => {
  const story = data.stories.find((s) => s.id === req.params.id);
  if (!story) return res.status(404).json({ error: 'История не найдена' });
  if (!story.viewedBy.includes(req.userId)) {
    story.viewedBy.push(req.userId);
    save();
  }
  res.json({ ok: true });
});

router.delete('/:id', (req, res) => {
  const idx = data.stories.findIndex((s) => s.id === req.params.id && s.userId === req.userId);
  if (idx === -1) return res.status(404).json({ error: 'История не найдена' });
  data.stories.splice(idx, 1);
  save();
  res.json({ ok: true });
});

module.exports = router;

const express = require('express');
const { data } = require('../db');
const { authMiddleware } = require('./auth');

const router = express.Router();
router.use(authMiddleware);

// GET /api/messages/:chatId?before=<timestamp>&date=YYYY-MM-DD&q=текст
router.get('/:chatId', (req, res) => {
  const { chatId } = req.params;
  const { before, date, q } = req.query;

  const chat = data.chats.find((c) => c.id === chatId);
  if (!chat || !chat.members.includes(req.userId)) return res.status(403).json({ error: 'Нет доступа' });

  let msgs = data.messages.filter((m) => m.chatId === chatId && !m.deletedAt && m.sentAt);

  if (date) {
    const start = new Date(`${date}T00:00:00`).getTime();
    const end = start + 24 * 60 * 60 * 1000;
    msgs = msgs.filter((m) => m.sentAt >= start && m.sentAt < end);
  }
  if (q) {
    const ql = String(q).toLowerCase();
    msgs = msgs.filter((m) => (m.text || '').toLowerCase().includes(ql));
  }

  msgs.sort((a, b) => a.sentAt - b.sentAt);
  if (before) msgs = msgs.filter((m) => m.sentAt < Number(before));

  res.json(msgs.slice(-100));
});

module.exports = router;

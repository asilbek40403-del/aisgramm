const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { data, save } = require('../db');
const { authMiddleware, publicUser } = require('./auth');

const router = express.Router();
router.use(authMiddleware);

function findMeta(chatId, userId) {
  return data.userChatMeta.find((m) => m.chatId === chatId && m.userId === userId);
}

// Список чатов пользователя вместе с папкой/закрепом/архивом и последним сообщением
router.get('/', (req, res) => {
  const metas = data.userChatMeta.filter((m) => m.userId === req.userId);
  const chats = metas
    .map((m) => {
      const chat = data.chats.find((c) => c.id === m.chatId);
      if (!chat) return null;
      const visibleMsgs = data.messages.filter(
        (msg) => msg.chatId === chat.id && !msg.deletedAt && msg.sentAt
      );
      const lastMsg = visibleMsgs.sort((a, b) => b.sentAt - a.sentAt)[0];
      const others = chat.members
        .filter((id) => id !== req.userId)
        .map((id) => {
          const u = data.users.find((uu) => uu.id === id);
          return u ? publicUser(u) : null;
        })
        .filter(Boolean);
      return {
        id: chat.id,
        type: chat.type,
        title: chat.type === 'private' ? others[0]?.displayName || chat.title : chat.title,
        description: chat.description || '',
        avatarUrl: chat.type === 'private' ? others[0]?.avatarUrl || null : chat.avatarUrl || null,
        avatarColor: chat.type === 'private' ? others[0]?.avatarColor : chat.avatarColor,
        members: others,
        membersCount: chat.members.length,
        ownerId: chat.ownerId || null,
        isOwner: chat.ownerId === req.userId,
        isAdmin: (chat.admins || []).includes(req.userId),
        peerPremium: chat.type === 'private' ? !!others[0]?.premium : false,
        peerNft: chat.type === 'private' ? others[0]?.nft || null : null,
        folder: m.folder,
        pinned: m.pinned,
        archived: m.archived,
        lastMessage: lastMsg
          ? { text: lastMsg.text, type: lastMsg.type, sentAt: lastMsg.sentAt, senderId: lastMsg.senderId }
          : null,
      };
    })
    .filter(Boolean);

  chats.sort((a, b) => Number(b.pinned) - Number(a.pinned) || (b.lastMessage?.sentAt || 0) - (a.lastMessage?.sentAt || 0));
  res.json(chats);
});

const GROUP_COLORS = ['#7bc862', '#65aadd', '#a695e7', '#ee7aae', '#6ec9cb', '#faa774'];

// Создать личный чат, группу или канал
router.post('/', (req, res) => {
  const { type, title, memberPhones, description, avatarUrl } = req.body || {};
  const t = type || 'private';
  let memberIds = [req.userId];

  (memberPhones || []).forEach((phone) => {
    const u = data.users.find((x) => x.phone === phone);
    if (u && !memberIds.includes(u.id)) memberIds.push(u.id);
  });

  if (t === 'private' && memberIds.length !== 2) {
    return res.status(400).json({ error: 'Укажите ровно одного существующего собеседника' });
  }

  if (t === 'private') {
    const existing = data.chats.find(
      (c) => c.type === 'private' && c.members.length === 2 && memberIds.every((id) => c.members.includes(id))
    );
    if (existing) return res.json({ id: existing.id });
  }

  if ((t === 'group' || t === 'channel') && !title) {
    return res.status(400).json({ error: 'Укажите название' });
  }

  const chat = {
    id: uuidv4(),
    type: t,
    title: title || 'Новый чат',
    members: memberIds,
    createdAt: Date.now(),
  };
  if (t === 'group' || t === 'channel') {
    chat.description = description || '';
    chat.avatarUrl = avatarUrl || null;
    chat.avatarColor = GROUP_COLORS[Math.floor(Math.random() * GROUP_COLORS.length)];
    chat.ownerId = req.userId; // "владелец" группы/канала
    chat.admins = [req.userId];
  }
  data.chats.push(chat);
  memberIds.forEach((uid) =>
    data.userChatMeta.push({
      userId: uid,
      chatId: chat.id,
      folder: t === 'channel' ? 'channels' : 'all',
      pinned: false,
      archived: false,
    })
  );
  save();
  res.json({ id: chat.id });
});

// Подробности чата (для настроек группы/канала: участники, владелец, аватар)
router.get('/:id', (req, res) => {
  const chat = data.chats.find((c) => c.id === req.params.id);
  if (!chat || !chat.members.includes(req.userId)) return res.status(404).json({ error: 'Чат не найден' });
  const members = chat.members.map((id) => {
    const u = data.users.find((x) => x.id === id);
    return u ? Object.assign(publicUser(u), { isOwner: id === chat.ownerId, isAdmin: (chat.admins || []).includes(id) }) : null;
  }).filter(Boolean);
  res.json({
    id: chat.id,
    type: chat.type,
    title: chat.title,
    description: chat.description || '',
    avatarUrl: chat.avatarUrl || null,
    avatarColor: chat.avatarColor,
    ownerId: chat.ownerId || null,
    admins: chat.admins || [],
    members,
  });
});

// Изменить название/описание/аватар группы или канала — только владелец/админ
router.patch('/:id', (req, res) => {
  const chat = data.chats.find((c) => c.id === req.params.id);
  if (!chat || !chat.members.includes(req.userId)) return res.status(404).json({ error: 'Чат не найден' });
  if (chat.type !== 'group' && chat.type !== 'channel') return res.status(400).json({ error: 'Недоступно для этого чата' });
  const isAdmin = chat.ownerId === req.userId || (chat.admins || []).includes(req.userId);
  if (!isAdmin) return res.status(403).json({ error: 'Только владелец или админ может менять настройки' });

  const { title, description, avatarUrl } = req.body || {};
  if (typeof title === 'string' && title.trim()) chat.title = title.trim();
  if (typeof description === 'string') chat.description = description.slice(0, 300);
  if (typeof avatarUrl === 'string') chat.avatarUrl = avatarUrl || null;
  save();
  res.json({ ok: true });
});

// Добавить участников в группу/канал по номеру телефона — владелец/админ
router.post('/:id/members', (req, res) => {
  const chat = data.chats.find((c) => c.id === req.params.id);
  if (!chat || !chat.members.includes(req.userId)) return res.status(404).json({ error: 'Чат не найден' });
  if (chat.type !== 'group' && chat.type !== 'channel') return res.status(400).json({ error: 'Недоступно для этого чата' });
  const isAdmin = chat.ownerId === req.userId || (chat.admins || []).includes(req.userId);
  if (!isAdmin) return res.status(403).json({ error: 'Только владелец или админ может добавлять участников' });

  const { phone } = req.body || {};
  const u = data.users.find((x) => x.phone === phone);
  if (!u) return res.status(404).json({ error: 'Пользователь не найден' });
  if (chat.members.includes(u.id)) return res.status(409).json({ error: 'Уже в чате' });

  chat.members.push(u.id);
  data.userChatMeta.push({ userId: u.id, chatId: chat.id, folder: chat.type === 'channel' ? 'channels' : 'all', pinned: false, archived: false });
  save();
  res.json({ ok: true });
});

// Покинуть группу/канал (владелец не может выйти, пока не назначит нового владельца)
router.post('/:id/leave', (req, res) => {
  const chat = data.chats.find((c) => c.id === req.params.id);
  if (!chat || !chat.members.includes(req.userId)) return res.status(404).json({ error: 'Чат не найден' });
  if (chat.ownerId === req.userId) return res.status(400).json({ error: 'Владелец не может покинуть чат' });
  chat.members = chat.members.filter((id) => id !== req.userId);
  chat.admins = (chat.admins || []).filter((id) => id !== req.userId);
  const idx = data.userChatMeta.findIndex((m) => m.chatId === chat.id && m.userId === req.userId);
  if (idx !== -1) data.userChatMeta.splice(idx, 1);
  save();
  res.json({ ok: true });
});

router.post('/:id/folder', (req, res) => {
  const meta = findMeta(req.params.id, req.userId);
  if (!meta) return res.status(404).json({ error: 'Чат не найден' });
  meta.folder = (req.body && req.body.folder) || 'all';
  save();
  res.json({ ok: true, folder: meta.folder });
});

router.post('/:id/pin', (req, res) => {
  const meta = findMeta(req.params.id, req.userId);
  if (!meta) return res.status(404).json({ error: 'Чат не найден' });
  meta.pinned = !meta.pinned;
  save();
  res.json({ pinned: meta.pinned });
});

router.post('/:id/archive', (req, res) => {
  const meta = findMeta(req.params.id, req.userId);
  if (!meta) return res.status(404).json({ error: 'Чат не найден' });
  meta.archived = !meta.archived;
  save();
  res.json({ archived: meta.archived });
});

module.exports = router;

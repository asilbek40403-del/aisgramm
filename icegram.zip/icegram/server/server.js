require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const { data, save } = require('./db');
const { router: authRouter, JWT_SECRET } = require('./routes/auth');
const chatsRouter = require('./routes/chats');
const messagesRouter = require('./routes/messages');
const uploadRouter = require('./routes/upload');
const storiesRouter = require('./routes/stories');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/auth', authRouter);
app.use('/api/chats', chatsRouter);
app.use('/api/messages', messagesRouter);
app.use('/api/upload', uploadRouter);
app.use('/api/stories', storiesRouter);

// Инлайн-бот-ассистент "@gif" — поиск гифок прямо в поле ввода (аналог @gif в Telegram).
// Используется публичный демо-ключ Giphy — для продакшена получите свой на developers.giphy.com
app.get('/api/inline/gif', async (req, res) => {
  const q = req.query.q || 'funny';
  try {
    const r = await fetch(
      `https://api.giphy.com/v1/gifs/search?api_key=dc6zaTOxFJmzC&q=${encodeURIComponent(q)}&limit=12&rating=g`
    );
    const j = await r.json();
    const results = (j.data || []).map((g) => ({
      url: g.images.fixed_height.url,
      preview: g.images.fixed_height_small.url,
    }));
    res.json(results);
  } catch (e) {
    res.json([]);
  }
});

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Авторизация сокета через тот же JWT, что и REST API
io.use((socket, next) => {
  const token = socket.handshake.auth && socket.handshake.auth.token;
  if (!token) return next(new Error('no token'));
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    socket.userId = payload.id;
    next();
  } catch (e) {
    next(new Error('bad token'));
  }
});

io.on('connection', (socket) => {
  const uid = socket.userId;

  // подключаем сокет ко всем комнатам (чатам), в которых состоит пользователь
  const chatIds = data.chats.filter((c) => c.members.includes(uid)).map((c) => c.id);
  chatIds.forEach((id) => socket.join(id));

  socket.on('chat:join', ({ chatId }) => {
    const chat = data.chats.find((c) => c.id === chatId);
    if (chat && chat.members.includes(uid)) socket.join(chatId);
  });

  // --- Текстовые/медиа сообщения ---
  socket.on('message:send', (payload, ack) => {
    const chat = data.chats.find((c) => c.id === payload.chatId);
    if (!chat || !chat.members.includes(uid)) return;

    // В каналах писать может только владелец/админы — как в Telegram
    if (chat.type === 'channel') {
      const isAdmin = chat.ownerId === uid || (chat.admins || []).includes(uid);
      if (!isAdmin) return;
    }

    const now = Date.now();
    const scheduledAt = payload.scheduledAt ? new Date(payload.scheduledAt).getTime() : null;
    const isFuture = scheduledAt && scheduledAt > now;

    const msg = {
      id: uuidv4(),
      chatId: payload.chatId,
      senderId: uid,
      type: payload.type || 'text', // text | photo | video | file | voice | video_note | location
      text: payload.text || '',
      fileUrl: payload.fileUrl || null,
      fileName: payload.fileName || null,
      fileSize: payload.fileSize || null,
      replyTo: payload.replyTo || null,
      lat: payload.lat ?? null,
      lng: payload.lng ?? null,
      isLive: !!payload.isLive,
      silent: !!payload.silent,
      scheduledAt: scheduledAt,
      sentAt: isFuture ? null : now,
      editedAt: null,
      deletedAt: null,
    };
    data.messages.push(msg);
    save();

    if (msg.sentAt) {
      io.to(chat.id).emit('message:new', msg);
    }
    if (ack) ack(msg);
  });

  socket.on('message:edit', ({ messageId, text }) => {
    const msg = data.messages.find((m) => m.id === messageId && m.senderId === uid);
    if (!msg) return;
    msg.text = text;
    msg.editedAt = Date.now();
    save();
    io.to(msg.chatId).emit('message:edited', msg);
  });

  // Удаление "без следа" — сообщение физически стирается у всех участников
  socket.on('message:delete', ({ messageId }) => {
    const idx = data.messages.findIndex((m) => m.id === messageId && m.senderId === uid);
    if (idx === -1) return;
    const chatId = data.messages[idx].chatId;
    data.messages.splice(idx, 1);
    save();
    io.to(chatId).emit('message:deleted', { messageId });
  });

  socket.on('typing', ({ chatId }) => {
    socket.to(chatId).emit('typing', { chatId, userId: uid });
  });

  // Живая геопозиция
  socket.on('location:live-update', ({ chatId, lat, lng, messageId }) => {
    const msg = data.messages.find((m) => m.id === messageId);
    if (msg) {
      msg.lat = lat;
      msg.lng = lng;
      save();
    }
    socket.to(chatId).emit('location:live-update', { chatId, lat, lng, messageId });
  });

  // --- WebRTC-сигналинг: аудио/видеозвонки + демонстрация экрана ---
  socket.on('call:invite', ({ chatId, callType }) => {
    socket.to(chatId).emit('call:incoming', { chatId, callType, fromUserId: uid });
  });
  socket.on('call:offer', ({ chatId, offer }) => {
    socket.to(chatId).emit('call:offer', { chatId, offer, fromUserId: uid });
  });
  socket.on('call:answer', ({ chatId, answer }) => {
    socket.to(chatId).emit('call:answer', { chatId, answer, fromUserId: uid });
  });
  socket.on('call:ice-candidate', ({ chatId, candidate }) => {
    socket.to(chatId).emit('call:ice-candidate', { chatId, candidate, fromUserId: uid });
  });
  socket.on('call:end', ({ chatId }) => {
    socket.to(chatId).emit('call:end', { chatId, fromUserId: uid });
  });
});

// Диспетчер отложенных сообщений — раз в 3 секунды проверяет очередь
setInterval(() => {
  const now = Date.now();
  let changed = false;
  data.messages.forEach((m) => {
    if (m.scheduledAt && !m.sentAt && m.scheduledAt <= now) {
      m.sentAt = now;
      changed = true;
      io.to(m.chatId).emit('message:new', m);
    }
  });
  if (changed) save();
}, 3000);

// Раз в минуту чистим просроченные (>24ч) истории — как в Telegram/Stories
setInterval(() => {
  const now = Date.now();
  const before = data.stories.length;
  data.stories = data.stories.filter((s) => s.expiresAt > now);
  if (data.stories.length !== before) save();
}, 60000);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✅ АйсГрам запущен: http://localhost:${PORT}`);
});

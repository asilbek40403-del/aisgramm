// ================== Состояние приложения ==================
let token = localStorage.getItem('token') || null;
let me = JSON.parse(localStorage.getItem('me') || 'null');
let socket = null;
let chats = [];
let activeFolder = 'all';
let currentChatId = null;
let currentChat = null;
let replyToMessage = null;

let pc = null;              // RTCPeerConnection текущего звонка
let localStream = null;
let currentCallChatId = null;
let screenTrackSender = null;

let mediaRecorder = null;
let recordedChunks = [];
let liveLocationWatchId = null;
let liveLocationMessageId = null;

const ICE_SERVERS = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

// ================== Новое состояние: профиль/группы/каналы/истории ==================
let nftPresets = [];
let allUsersCache = [];
let createChatType = 'group';   // 'group' | 'channel'
let createChatSelectedAvatarUrl = null;
let settingsChatId = null;
let settingsAvatarUrl = null;

let storyGroups = [];      // список [{user, stories, allViewed}] от GET /api/stories
let storyGroupIdx = -1;
let storyIdx = 0;
let storyTimer = null;
let storyTimerStart = 0;
let storyTimerDuration = 5000;

// ================== Аватарки (картинка / цвет / NFT-рамка / премиум) ==================
function avatarBlock(opts) {
  const { title, avatarUrl, avatarColor, emoji, nft, size } = opts || {};
  const cls = 'avatar' + (size ? ' ' + size : '');
  const style = avatarUrl
    ? `background-image:url('${avatarUrl}')`
    : `background:${avatarColor || '#888'}`;
  const content = avatarUrl ? '' : (emoji || initials(title));
  const badge = nft ? `<div class="nft-ring-badge" title="${escapeHtml(nft.name || '')}">${nft.emoji}</div>` : '';
  return `<span style="position:relative;display:inline-flex;flex-shrink:0">
    <div class="${cls}" style="${style}">${content}</div>${badge}
  </span>`;
}

function nameWithPremium(name, premium) {
  return escapeHtml(name) + (premium ? ' <span class="premium-star" title="Premium">⭐</span>' : '');
}

// ================== Вспомогательные функции ==================
function $(sel) { return document.querySelector(sel); }
function $all(sel) { return Array.from(document.querySelectorAll(sel)); }

async function api(path, opts = {}) {
  const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
  if (token) headers.Authorization = 'Bearer ' + token;
  const res = await fetch('/api' + path, Object.assign({}, opts, { headers }));
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Ошибка запроса' }));
    throw new Error(err.error || 'Ошибка запроса');
  }
  return res.status === 204 ? null : res.json();
}

function fmtTime(ts) {
  return new Date(ts).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

function initials(name) {
  return (name || '?').trim().charAt(0).toUpperCase();
}

// ================== Экран аутентификации ==================
// Вход/регистрация обычных пользователей — по номеру телефона и SMS-коду
// подтверждения, аналогично Telegram. Владелец входит отдельно, по паролю.
let authMode = 'login'; // 'login' | 'register' | 'owner'
let pendingPhone = null;
let pendingIsNewUser = false;

$('#tab-login').onclick = () => setAuthMode('login');
$('#tab-register').onclick = () => setAuthMode('register');
$('#tab-owner').onclick = () => setAuthMode('owner');

function setAuthMode(mode) {
  authMode = mode;
  $('#tab-login').classList.toggle('active', mode === 'login');
  $('#tab-register').classList.toggle('active', mode === 'register');
  $('#tab-owner').classList.toggle('active', mode === 'owner');
  $('#auth-phone-flow').classList.toggle('hidden', mode === 'owner');
  $('#auth-owner-flow').classList.toggle('hidden', mode !== 'owner');
  $('#auth-code-block').classList.add('hidden');
  $('#auth-demo-hint').classList.add('hidden');
  $('#auth-phone').value = '';
  $('#auth-code').value = '';
  pendingPhone = null;
  $('#auth-error').textContent = '';
}

$('#auth-send-code-btn').onclick = async () => {
  const phone = $('#auth-phone').value.trim();
  $('#auth-error').textContent = '';
  if (!phone) { $('#auth-error').textContent = 'Введите номер телефона'; return; }
  try {
    const resp = await api('/auth/send-code', { method: 'POST', body: JSON.stringify({ phone }) });
    pendingPhone = phone;
    pendingIsNewUser = resp.isNewUser;
    $('#auth-code-block').classList.remove('hidden');
    $('#auth-displayname').style.display = pendingIsNewUser ? 'block' : 'none';
    $('#auth-new-password').style.display = pendingIsNewUser ? 'block' : 'none';
    if (resp.devCode) {
      $('#auth-demo-hint').textContent = `Демо-режим (нет подключённого SMS-провайдера): ваш код — ${resp.devCode}`;
      $('#auth-demo-hint').classList.remove('hidden');
    }
  } catch (e) {
    $('#auth-error').textContent = e.message;
  }
};

$('#auth-verify-code-btn').onclick = async () => {
  const code = $('#auth-code').value.trim();
  $('#auth-error').textContent = '';
  if (!pendingPhone) { $('#auth-error').textContent = 'Сначала запросите код'; return; }
  if (!code) { $('#auth-error').textContent = 'Введите код из SMS'; return; }
  const body = { phone: pendingPhone, code };
  if (pendingIsNewUser) {
    body.displayName = $('#auth-displayname').value.trim();
    body.password = $('#auth-new-password').value;
  }
  try {
    const data = await api('/auth/verify-code', { method: 'POST', body: JSON.stringify(body) });
    token = data.token;
    me = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('me', JSON.stringify(me));
    startApp();
  } catch (e) {
    $('#auth-error').textContent = e.message;
  }
};

$('#owner-login-btn').onclick = async () => {
  const phone = $('#owner-phone').value.trim();
  const password = $('#owner-password').value;
  $('#auth-error').textContent = '';
  if (!phone || !password) { $('#auth-error').textContent = 'Введите телефон и пароль владельца'; return; }
  try {
    const data = await api('/auth/owner-login', { method: 'POST', body: JSON.stringify({ phone, password }) });
    token = data.token;
    me = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('me', JSON.stringify(me));
    startApp();
  } catch (e) {
    $('#auth-error').textContent = e.message;
  }
};

// ================== Запуск приложения после входа ==================
async function startApp() {
  $('#auth-screen').classList.add('hidden');
  $('#app').classList.remove('hidden');
  renderMeHeader();

  socket = io({ auth: { token } });
  socket.on('message:new', onIncomingMessage);
  socket.on('message:edited', onMessageEdited);
  socket.on('message:deleted', onMessageDeleted);
  socket.on('typing', onTyping);
  socket.on('location:live-update', onLiveLocationUpdate);

  socket.on('call:incoming', onCallIncoming);
  socket.on('call:offer', onCallOffer);
  socket.on('call:answer', onCallAnswer);
  socket.on('call:ice-candidate', onRemoteIceCandidate);
  socket.on('call:end', onCallEndedRemote);

  try {
    me = await api('/auth/me');
    localStorage.setItem('me', JSON.stringify(me));
    renderMeHeader();
  } catch (e) {}

  try {
    nftPresets = await api('/auth/nft-presets');
  } catch (e) {}

  loadChats();
  loadStories();
}

function renderMeHeader() {
  $('#me-avatar-wrap').innerHTML = avatarBlock({ title: me.displayName, avatarUrl: me.avatarUrl, avatarColor: me.avatarColor, nft: me.nft });
  $('#me-name').innerHTML = nameWithPremium(me.displayName, me.premium);
  $('#admin-panel-btn').classList.toggle('hidden', !me.isOwner);
}

if (token && me) startApp();

// ================== Список чатов и папки ==================
async function loadChats() {
  chats = await api('/chats');
  renderChatList();
}

$all('.folder-tab').forEach((btn) => {
  btn.onclick = () => {
    activeFolder = btn.dataset.folder;
    $all('.folder-tab').forEach((b) => b.classList.toggle('active', b === btn));
    renderChatList();
  };
});

$('#global-search').oninput = renderChatList;

function renderChatList() {
  const q = $('#global-search').value.trim().toLowerCase();
  const list = $('#chat-list');
  list.innerHTML = '';

  chats
    .filter((c) => (activeFolder === 'archived' ? c.archived : !c.archived && (activeFolder === 'all' || c.folder === activeFolder)))
    .filter((c) => !q || c.title.toLowerCase().includes(q))
    .forEach((c) => {
      const div = document.createElement('div');
      div.className = 'chat-item' + (c.id === currentChatId ? ' active' : '');
      const last = c.lastMessage;
      const preview = last ? describeMessagePreview(last) : 'Нет сообщений';
      const typeIcon = c.type === 'saved' ? '⭐' : c.type === 'group' ? '👥' : c.type === 'channel' ? '📢' : null;
      const av = c.type === 'saved'
        ? avatarBlock({ emoji: '⭐', avatarColor: '#3f9142' })
        : avatarBlock({ title: c.title, avatarUrl: c.avatarUrl, avatarColor: c.avatarColor || '#888', emoji: typeIcon, nft: c.peerNft });
      div.innerHTML = `
        ${av}
        <div class="chat-item-body">
          <div class="chat-item-title">${c.pinned ? '<span class="pin-icon">📌</span>' : ''}${nameWithPremium(c.title, c.peerPremium)}</div>
          <div class="chat-item-last">${escapeHtml(preview)}</div>
        </div>`;
      div.onclick = () => selectChat(c.id);
      list.appendChild(div);
    });
}

function describeMessagePreview(m) {
  const map = { text: m.text, photo: '📷 Фото', video: '🎬 Видео', file: '📄 Файл', voice: '🎤 Голосовое сообщение', video_note: '⏺️ Видеосообщение', location: '📍 Геопозиция' };
  return map[m.type] || '';
}

function escapeHtml(s) {
  return (s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ================== Создание нового чата (личный / группа / канал) ==================
$('#new-chat-btn').onclick = () => $('#new-chat-menu').classList.toggle('hidden');
document.addEventListener('click', (e) => {
  if (!e.target.closest('.new-chat-menu-wrap')) $('#new-chat-menu').classList.add('hidden');
});

$all('#new-chat-menu button').forEach((btn) => {
  btn.onclick = () => {
    $('#new-chat-menu').classList.add('hidden');
    const kind = btn.dataset.kind;
    if (kind === 'private') createPrivateChat();
    else openCreateChatModal(kind);
  };
});

async function createPrivateChat() {
  const phone = prompt('Введите номер телефона собеседника:');
  if (!phone) return;
  try {
    const res = await api('/chats', { method: 'POST', body: JSON.stringify({ type: 'private', memberPhones: [phone] }) });
    await loadChats();
    selectChat(res.id);
  } catch (e) {
    alert(e.message);
  }
}

// ---- Модалка создания группы/канала ----
async function openCreateChatModal(kind) {
  createChatType = kind;
  createChatSelectedAvatarUrl = null;
  $('#create-chat-avatar').style.backgroundImage = '';
  $('#create-chat-avatar').textContent = '📷';
  $('#create-chat-title').textContent = kind === 'group' ? 'Новая группа' : 'Новый канал';
  $('#create-chat-name-label').textContent = kind === 'group' ? 'Название группы' : 'Название канала';
  $('#create-chat-name').value = '';
  $('#create-chat-desc').value = '';
  $('#create-chat-error').textContent = '';
  $('#create-chat-members-block').style.display = kind === 'group' ? 'block' : 'none';

  if (kind === 'group') {
    allUsersCache = await api('/auth/users');
    const list = $('#create-chat-members-list');
    list.innerHTML = '';
    allUsersCache.filter((u) => u.id !== me.id).forEach((u) => {
      const row = document.createElement('label');
      row.className = 'member-pick-item';
      row.innerHTML = `${avatarBlock({ title: u.displayName, avatarUrl: u.avatarUrl, avatarColor: u.avatarColor })}
        <span>${nameWithPremium(u.displayName, u.premium)}</span>
        <input type="checkbox" value="${escapeHtml(u.phone)}">`;
      list.appendChild(row);
    });
  }
  $('#create-chat-modal').classList.remove('hidden');
}

$('#create-chat-avatar-btn').onclick = () => $('#create-chat-avatar-input').click();
$('#create-chat-avatar-input').onchange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const url = await uploadRaw(file);
  if (url) {
    createChatSelectedAvatarUrl = url;
    $('#create-chat-avatar').style.backgroundImage = `url('${url}')`;
    $('#create-chat-avatar').textContent = '';
  }
  e.target.value = '';
};

$('#create-chat-submit-btn').onclick = async () => {
  const title = $('#create-chat-name').value.trim();
  if (!title) { $('#create-chat-error').textContent = 'Укажите название'; return; }
  const memberPhones = createChatType === 'group'
    ? $all('#create-chat-members-list input:checked').map((i) => i.value)
    : [];
  try {
    const res = await api('/chats', {
      method: 'POST',
      body: JSON.stringify({
        type: createChatType,
        title,
        description: $('#create-chat-desc').value.trim(),
        avatarUrl: createChatSelectedAvatarUrl,
        memberPhones,
      }),
    });
    closeModal('create-chat-modal');
    await loadChats();
    selectChat(res.id);
  } catch (e) {
    $('#create-chat-error').textContent = e.message;
  }
};

// Загрузка файла без немедленной отправки сообщением — используется для аватарок и историй
async function uploadRaw(file) {
  const form = new FormData();
  form.append('file', file);
  const res = await fetch('/api/upload', { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: form });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.error || 'Не удалось загрузить файл');
    return null;
  }
  const data = await res.json();
  return data.url;
}

function closeModal(id) { $('#' + id).classList.add('hidden'); }
$all('.modal-close').forEach((btn) => {
  btn.onclick = () => closeModal(btn.dataset.close);
});
$all('.modal-overlay').forEach((ov) => {
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) ov.classList.add('hidden'); });
});

// ================== Выбор чата и загрузка сообщений ==================
async function selectChat(chatId) {
  currentChatId = chatId;
  currentChat = chats.find((c) => c.id === chatId);
  socket.emit('chat:join', { chatId });

  $('#empty-state').classList.add('hidden');
  $('#chat-view').classList.remove('hidden');
  $('#chat-title').innerHTML = nameWithPremium(currentChat.title, currentChat.peerPremium);
  const typeIcon = currentChat.type === 'group' ? '👥' : currentChat.type === 'channel' ? '📢' : null;
  $('#chat-avatar-slot').innerHTML = avatarBlock({
    title: currentChat.title, avatarUrl: currentChat.avatarUrl, avatarColor: currentChat.avatarColor || '#888',
    emoji: currentChat.type === 'saved' ? '⭐' : typeIcon, nft: currentChat.peerNft,
  });
  const canPostChannel = currentChat.type !== 'channel' || currentChat.isOwner || currentChat.isAdmin;
  $('#chat-subtitle').textContent = currentChat.type === 'saved' ? 'Личное облако'
    : currentChat.type === 'private' ? 'Личный чат'
    : currentChat.type === 'group' ? `Группа · ${currentChat.membersCount} уч.`
    : `Канал · ${currentChat.membersCount} подпис.${canPostChannel ? '' : ' · писать могут только админы'}`;
  document.querySelector('.composer').classList.toggle('hidden', !canPostChannel);
  $('#chat-header-info').onclick = () => {
    if (currentChat.type === 'group' || currentChat.type === 'channel') openChatSettings(currentChat.id);
  };
  $('#chat-header-info').style.cursor = (currentChat.type === 'group' || currentChat.type === 'channel') ? 'pointer' : 'default';
  $('#pin-btn').style.opacity = currentChat.pinned ? 1 : 0.5;
  $('#archive-btn').style.opacity = currentChat.archived ? 1 : 0.5;
  $('#folder-select').value = currentChat.folder || 'all';
  $('#date-search').value = '';
  cancelReply();
  renderChatList();

  const msgs = await api('/messages/' + chatId);
  const box = $('#messages');
  box.innerHTML = '';
  msgs.forEach((m) => renderMessage(m));
  box.scrollTop = box.scrollHeight;
}

$('#date-search').onchange = async () => {
  const date = $('#date-search').value;
  const msgs = await api(`/messages/${currentChatId}` + (date ? `?date=${date}` : ''));
  const box = $('#messages');
  box.innerHTML = '';
  msgs.forEach((m) => renderMessage(m));
  box.scrollTop = box.scrollHeight;
};

$('#pin-btn').onclick = async () => {
  const r = await api(`/chats/${currentChatId}/pin`, { method: 'POST' });
  $('#pin-btn').style.opacity = r.pinned ? 1 : 0.5;
  await loadChats();
};
$('#archive-btn').onclick = async () => {
  const r = await api(`/chats/${currentChatId}/archive`, { method: 'POST' });
  $('#archive-btn').style.opacity = r.archived ? 1 : 0.5;
  await loadChats();
};
$('#folder-select').onchange = async (e) => {
  await api(`/chats/${currentChatId}/folder`, { method: 'POST', body: JSON.stringify({ folder: e.target.value }) });
  await loadChats();
};

// ================== Рендер сообщений ==================
function renderMessage(m) {
  const box = $('#messages');
  const row = document.createElement('div');
  row.className = 'msg-row ' + (m.senderId === me.id ? 'out' : 'in');
  row.dataset.id = m.id;

  const bubble = document.createElement('div');
  bubble.className = 'bubble';

  let inner = '';
  if (m.replyTo) {
    const replied = findMessageInDom(m.replyTo);
    inner += `<div class="reply-quote">${escapeHtml(replied || 'Сообщение')}</div>`;
  }

  if (m.type === 'text') {
    inner += `<div>${linkifyTimecodes(escapeHtml(m.text))}</div>`;
  } else if (m.type === 'photo') {
    inner += `<img src="${m.fileUrl}" alt="photo">`;
    if (m.text) inner += `<div>${escapeHtml(m.text)}</div>`;
  } else if (m.type === 'video') {
    inner += `<video class="attach" controls id="video-${m.id}"><source src="${m.fileUrl}"></video>`;
    if (m.text) inner += `<div>${linkifyTimecodes(escapeHtml(m.text), m.id)}</div>`;
  } else if (m.type === 'video_note') {
    inner += `<video class="video-note" autoplay loop muted><source src="${m.fileUrl}"></video>`;
  } else if (m.type === 'voice') {
    inner += `<audio controls src="${m.fileUrl}"></audio>`;
  } else if (m.type === 'file') {
    inner += `<div class="filecard">📄 <a href="${m.fileUrl}" target="_blank" download>${escapeHtml(m.fileName || 'файл')}</a> <span style="opacity:.6">(${fmtSize(m.fileSize)})</span></div>`;
  } else if (m.type === 'location') {
    const mapId = 'map-' + m.id;
    inner += `<div class="map-embed" id="${mapId}"></div>${m.isLive ? '<div class="live-badge">🔴 Трансляция геопозиции</div>' : ''}`;
    setTimeout(() => renderMap(mapId, m.lat, m.lng), 0);
  }

  const edited = m.editedAt ? ' <span title="Отредактировано">(ред.)</span>' : '';
  inner += `<div class="meta">${fmtTime(m.sentAt)}${edited}${m.silent ? ' 🔕' : ''}</div>`;

  if (m.senderId === me.id && (m.type === 'text' || m.type === 'photo')) {
    inner += `<div class="msg-actions">
      <button onclick="startEdit('${m.id}')" title="Редактировать">✏️</button>
      <button onclick="deleteMessage('${m.id}')" title="Удалить без следа">🗑️</button>
    </div>`;
  } else if (m.senderId === me.id) {
    inner += `<div class="msg-actions"><button onclick="deleteMessage('${m.id}')" title="Удалить без следа">🗑️</button></div>`;
  }

  bubble.innerHTML = inner;
  bubble.oncontextmenu = (e) => { e.preventDefault(); startReply(m); };
  bubble.ondblclick = () => startReply(m);
  row.appendChild(bubble);
  box.appendChild(row);
}

function findMessageInDom(id) {
  const row = document.querySelector(`.msg-row[data-id="${id}"] .bubble`);
  return row ? row.textContent.slice(0, 60) : null;
}

function fmtSize(bytes) {
  if (!bytes) return '';
  const mb = bytes / (1024 * 1024);
  return mb >= 1 ? mb.toFixed(1) + ' МБ' : (bytes / 1024).toFixed(0) + ' КБ';
}

// Таймкоды вида 1:23 в подписи к видео становятся кликабельными и перематывают плеер
function linkifyTimecodes(text, videoMsgId) {
  return text.replace(/\b(\d{1,2}):([0-5]\d)\b/g, (match, mm, ss) => {
    const seconds = Number(mm) * 60 + Number(ss);
    return videoMsgId
      ? `<span class="timecode" onclick="seekVideo('${videoMsgId}', ${seconds})">${match}</span>`
      : match;
  });
}
window.seekVideo = function (msgId, seconds) {
  const v = document.getElementById('video-' + msgId);
  if (v) { v.currentTime = seconds; v.play(); }
};

function renderMap(elId, lat, lng) {
  if (!window.L) return;
  const el = document.getElementById(elId);
  if (!el || el._leaflet_id) return;
  const map = L.map(elId, { zoomControl: false, attributionControl: false }).setView([lat, lng], 14);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
  const marker = L.marker([lat, lng]).addTo(map);
  el._map = map; el._marker = marker;
}

// ================== Входящие события сокета ==================
function onIncomingMessage(m) {
  if (m.chatId === currentChatId) {
    renderMessage(m);
    $('#messages').scrollTop = $('#messages').scrollHeight;
  }
  if (!m.silent && m.senderId !== me.id) {
    playNotificationBeep();
  }
  loadChats();
}

function onMessageEdited(m) {
  const row = document.querySelector(`.msg-row[data-id="${m.id}"]`);
  if (row) { row.remove(); }
  if (m.chatId === currentChatId) renderMessage(m);
}

function onMessageDeleted({ messageId }) {
  const row = document.querySelector(`.msg-row[data-id="${messageId}"]`);
  if (row) row.remove();
}

let typingTimeout = null;
function onTyping({ chatId }) {
  if (chatId !== currentChatId) return;
  $('#chat-subtitle').textContent = 'печатает…';
  clearTimeout(typingTimeout);
  typingTimeout = setTimeout(() => {
    $('#chat-subtitle').textContent = currentChat.type === 'private' ? 'Личный чат' : currentChat.type;
  }, 2000);
}

function onLiveLocationUpdate({ lat, lng, messageId }) {
  const mapId = 'map-' + messageId;
  const el = document.getElementById(mapId);
  if (el && el._map) {
    el._map.setView([lat, lng]);
    el._marker.setLatLng([lat, lng]);
  }
}

function playNotificationBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    o.frequency.value = 880;
    o.connect(ctx.destination);
    o.start(); o.stop(ctx.currentTime + 0.08);
  } catch (e) {}
}

// ================== Отправка/редактирование/удаление ==================
const textInput = $('#text-input');
textInput.addEventListener('input', () => {
  textInput.style.height = 'auto';
  textInput.style.height = Math.min(textInput.scrollHeight, 110) + 'px';
  if (currentChatId) socket.emit('typing', { chatId: currentChatId });
  handleInlineGifTrigger();
});
textInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendTextMessage(); }
});

$('#send-btn').onclick = sendTextMessage;

function sendTextMessage() {
  const text = textInput.value.trim();
  if (!text || !currentChatId) return;
  sendMessage({ type: 'text', text });
  textInput.value = '';
  textInput.style.height = 'auto';
  $('#gif-panel').classList.add('hidden');
}

function sendMessage(partial) {
  if (!currentChatId) return;
  const scheduledAt = $('#schedule-input').value || null;
  const payload = Object.assign(
    {
      chatId: currentChatId,
      silent: $('#silent-check').checked,
      scheduledAt,
      replyTo: replyToMessage ? replyToMessage.id : null,
    },
    partial
  );
  socket.emit('message:send', payload, () => {});
  cancelReply();
  $('#schedule-input').value = '';
  $('#silent-check').checked = false;
}

window.startEdit = function (id) {
  const bubble = document.querySelector(`.msg-row[data-id="${id}"] .bubble > div:first-child`);
  const current = bubble ? bubble.textContent : '';
  const next = prompt('Изменить сообщение:', current);
  if (next === null || next.trim() === '') return;
  socket.emit('message:edit', { messageId: id, text: next.trim() });
};

window.deleteMessage = function (id) {
  if (!confirm('Удалить сообщение без следа у всех участников?')) return;
  socket.emit('message:delete', { messageId: id });
};

// ================== Ответ на сообщение ==================
function startReply(m) {
  replyToMessage = m;
  $('#reply-preview').classList.remove('hidden');
  $('#reply-text').textContent = 'Ответ: ' + (m.text || describeMessagePreview(m)).slice(0, 60);
  textInput.focus();
}
function cancelReply() {
  replyToMessage = null;
  $('#reply-preview').classList.add('hidden');
}
$('#reply-cancel').onclick = cancelReply;

// ================== Настройки группы/канала (аватар, название, участники) ==================
async function openChatSettings(chatId) {
  settingsChatId = chatId;
  settingsAvatarUrl = null;
  $('#settings-error').textContent = '';
  const chat = await api('/chats/' + chatId);
  const isAdmin = chat.ownerId === me.id || (chat.admins || []).includes(me.id);

  $('#chat-settings-title').textContent = chat.type === 'group' ? 'Настройки группы' : 'Настройки канала';
  $('#settings-avatar').style.backgroundImage = chat.avatarUrl ? `url('${chat.avatarUrl}')` : '';
  $('#settings-avatar').textContent = chat.avatarUrl ? '' : (chat.type === 'group' ? '👥' : '📢');
  $('#settings-avatar').style.background = chat.avatarUrl ? '' : (chat.avatarColor || '#888');
  $('#settings-name').value = chat.title;
  $('#settings-desc').value = chat.description || '';
  $('#settings-name').disabled = !isAdmin;
  $('#settings-desc').disabled = !isAdmin;
  $('#settings-avatar-btn').style.display = isAdmin ? 'inline-block' : 'none';
  $('#settings-save-btn').style.display = isAdmin ? 'block' : 'none';
  document.querySelector('#chat-settings-modal .modal-divider').style.display = isAdmin ? 'block' : 'none';
  const addLabel = $all('#chat-settings-modal label')[2];
  if (addLabel) addLabel.style.display = isAdmin ? 'block' : 'none';
  $('.add-member-row').style.display = isAdmin ? 'flex' : 'none';

  const list = $('#settings-members-list');
  list.innerHTML = '';
  chat.members.forEach((u) => {
    const row = document.createElement('div');
    row.className = 'settings-member-item';
    const role = u.id === chat.ownerId ? '👑 Владелец' : u.isAdmin ? 'Админ' : '';
    row.innerHTML = `${avatarBlock({ title: u.displayName, avatarUrl: u.avatarUrl, avatarColor: u.avatarColor, nft: u.nft })}
      <span>${nameWithPremium(u.displayName, u.premium)}</span>
      ${role ? `<span class="role-badge">${role}</span>` : ''}`;
    list.appendChild(row);
  });

  $('#chat-settings-modal').classList.remove('hidden');
}

$('#settings-avatar-btn').onclick = () => $('#settings-avatar-input').click();
$('#settings-avatar-input').onchange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const url = await uploadRaw(file);
  if (url) {
    settingsAvatarUrl = url;
    $('#settings-avatar').style.backgroundImage = `url('${url}')`;
    $('#settings-avatar').textContent = '';
  }
  e.target.value = '';
};

$('#settings-save-btn').onclick = async () => {
  try {
    const body = { title: $('#settings-name').value.trim(), description: $('#settings-desc').value.trim() };
    if (settingsAvatarUrl) body.avatarUrl = settingsAvatarUrl;
    await api('/chats/' + settingsChatId, { method: 'PATCH', body: JSON.stringify(body) });
    closeModal('chat-settings-modal');
    await loadChats();
    if (currentChatId === settingsChatId) selectChat(settingsChatId);
  } catch (e) {
    $('#settings-error').textContent = e.message;
  }
};

$('#settings-add-btn').onclick = async () => {
  const phone = $('#settings-add-username').value.trim();
  if (!phone) return;
  try {
    await api(`/chats/${settingsChatId}/members`, { method: 'POST', body: JSON.stringify({ phone }) });
    $('#settings-add-username').value = '';
    openChatSettings(settingsChatId);
  } catch (e) {
    $('#settings-error').textContent = e.message;
  }
};

// ================== Профиль: аватар, Premium, NFT-бейдж ==================
$('#me-avatar-wrap').onclick = openProfileModal;
$('#me-name').onclick = openProfileModal;

async function openProfileModal() {
  $('#profile-avatar').style.backgroundImage = me.avatarUrl ? `url('${me.avatarUrl}')` : '';
  $('#profile-avatar').style.background = me.avatarUrl ? '' : (me.avatarColor || '#888');
  $('#profile-avatar').textContent = me.avatarUrl ? '' : initials(me.displayName);
  $('#profile-displayname').value = me.displayName;
  $('#profile-bio').value = me.bio || '';

  $('#premium-status-desc').textContent = me.premium
    ? '⭐ У вас активен Premium — выдан владельцем.'
    : 'Premium не активен. Golden-бейдж выдаётся только владельцем аккаунта.';

  const badgeBox = $('#nft-current-badge');
  badgeBox.innerHTML = me.nft
    ? `<div class="nft-item selected"><div class="nft-emoji">${me.nft.emoji}</div><div>${escapeHtml(me.nft.name)}</div></div>`
    : `<div class="nft-item"><div class="nft-emoji">🚫</div><div>Бейдж не выдан</div></div>`;

  $('#old-password').value = '';
  $('#new-password').value = '';
  $('#new-password-confirm').value = '';
  $('#password-msg').textContent = '';

  $('#profile-modal').classList.remove('hidden');
}

$('#profile-avatar-upload-btn').onclick = () => $('#profile-avatar-input').click();
$('#profile-avatar-input').onchange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const url = await uploadRaw(file);
  if (url) {
    me = await api('/auth/profile', { method: 'PATCH', body: JSON.stringify({ avatarUrl: url }) });
    localStorage.setItem('me', JSON.stringify(me));
    renderMeHeader();
    openProfileModal();
    loadChats();
  }
  e.target.value = '';
};

$('#profile-save-btn').onclick = async () => {
  me = await api('/auth/profile', {
    method: 'PATCH',
    body: JSON.stringify({ displayName: $('#profile-displayname').value.trim(), bio: $('#profile-bio').value.trim() }),
  });
  localStorage.setItem('me', JSON.stringify(me));
  renderMeHeader();
  closeModal('profile-modal');
  loadChats();
};

// ================== Смена пароля ==================
$('#change-password-btn').onclick = async () => {
  const oldPassword = $('#old-password').value;
  const newPassword = $('#new-password').value;
  const confirm = $('#new-password-confirm').value;
  $('#password-msg').textContent = '';
  if (!oldPassword || !newPassword) {
    $('#password-msg').textContent = 'Заполните оба поля пароля';
    return;
  }
  if (newPassword !== confirm) {
    $('#password-msg').textContent = 'Новые пароли не совпадают';
    return;
  }
  try {
    await api('/auth/change-password', { method: 'POST', body: JSON.stringify({ oldPassword, newPassword }) });
    $('#password-msg').style.color = 'var(--accent, #4dabf7)';
    $('#password-msg').textContent = 'Пароль успешно изменён';
    $('#old-password').value = '';
    $('#new-password').value = '';
    $('#new-password-confirm').value = '';
  } catch (e) {
    $('#password-msg').style.color = '';
    $('#password-msg').textContent = e.message;
  }
};

// ================== Админ-панель владельца: выдача Premium/NFT ==================
$('#admin-panel-btn').onclick = openAdminModal;

async function openAdminModal() {
  if (!nftPresets.length) nftPresets = await api('/auth/nft-presets');
  const users = await api('/auth/admin/users');
  const list = $('#admin-users-list');
  list.innerHTML = '';
  users.filter((u) => !u.isOwner).forEach((u) => {
    const row = document.createElement('div');
    row.className = 'admin-user-row';
    const nftOptions = ['<option value="">Без бейджа</option>']
      .concat(nftPresets.map((p) => `<option value="${p.id}" ${u.nft && u.nft.id === p.id ? 'selected' : ''}>${p.emoji} ${escapeHtml(p.name)}</option>`))
      .join('');
    row.innerHTML = `
      ${avatarBlock({ title: u.displayName, avatarUrl: u.avatarUrl, avatarColor: u.avatarColor, nft: u.nft })}
      <div class="admin-user-info">
        <div class="admin-user-name">${nameWithPremium(u.displayName, u.premium)}</div>
        <div class="admin-user-phone">${escapeHtml(u.phone || '')}</div>
      </div>
      <label class="admin-premium-toggle">
        <input type="checkbox" data-uid="${u.id}" class="admin-premium-check" ${u.premium ? 'checked' : ''}> Premium
      </label>
      <select data-uid="${u.id}" class="admin-nft-select">${nftOptions}</select>
    `;
    list.appendChild(row);
  });

  $all('.admin-premium-check').forEach((el) => {
    el.onchange = async () => {
      await api(`/auth/admin/users/${el.dataset.uid}/premium`, { method: 'POST', body: JSON.stringify({ enable: el.checked }) });
    };
  });
  $all('.admin-nft-select').forEach((el) => {
    el.onchange = async () => {
      await api(`/auth/admin/users/${el.dataset.uid}/nft`, { method: 'POST', body: JSON.stringify({ presetId: el.value || null }) });
    };
  });

  $('#admin-modal').classList.remove('hidden');
}

// ================== Истории (Stories) — фото/видео-статусы на 24 часа ==================
async function loadStories() {
  try {
    storyGroups = await api('/stories');
  } catch (e) {
    storyGroups = [];
  }
  renderStoriesBar();
}

function renderStoriesBar() {
  const bar = $('#stories-bar');
  bar.innerHTML = '';

  const myGroup = storyGroups.find((g) => g.user.id === me.id);

  // "Моя история" — всегда первый кружок, с плюсиком для добавления
  const mine = document.createElement('div');
  mine.className = 'story-circle';
  const ringClass = myGroup && myGroup.stories.length ? '' : 'mine-empty';
  mine.innerHTML = `
    <span style="position:relative;display:inline-flex">
      <div class="story-ring ${ringClass}">${avatarBlock({ title: me.displayName, avatarUrl: me.avatarUrl, avatarColor: me.avatarColor, nft: me.nft })}</div>
      <div class="story-add-badge">+</div>
    </span>
    <div class="story-label">Мои</div>`;
  mine.onclick = () => {
    if (myGroup && myGroup.stories.length) openStoryViewer(storyGroups.findIndex((g) => g.user.id === me.id));
    else $('#story-create-input').click();
  };
  bar.appendChild(mine);

  storyGroups.filter((g) => g.user.id !== me.id).forEach((g) => {
    const el = document.createElement('div');
    el.className = 'story-circle';
    el.innerHTML = `
      <div class="story-ring ${g.allViewed ? 'viewed' : ''}">${avatarBlock({ title: g.user.displayName, avatarUrl: g.user.avatarUrl, avatarColor: g.user.avatarColor, nft: g.user.nft })}</div>
      <div class="story-label">${escapeHtml(g.user.displayName)}</div>`;
    el.onclick = () => openStoryViewer(storyGroups.findIndex((x) => x.user.id === g.user.id));
    bar.appendChild(el);
  });
}

$('#story-create-input').onchange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const url = await uploadRaw(file);
  if (url) {
    const type = file.type.startsWith('video/') ? 'video' : 'photo';
    await api('/stories', { method: 'POST', body: JSON.stringify({ type, fileUrl: url }) });
    await loadStories();
  }
  e.target.value = '';
};

function openStoryViewer(groupIndex) {
  storyGroupIdx = groupIndex;
  storyIdx = 0;
  $('#story-viewer').classList.remove('hidden');
  playCurrentStory();
}

function playCurrentStory() {
  clearTimeout(storyTimer);
  const group = storyGroups[storyGroupIdx];
  if (!group) return closeStoryViewer();
  const story = group.stories[storyIdx];
  if (!story) { advanceGroup(1); return; }

  if (!story.mine) api('/stories/' + story.id + '/view', { method: 'POST' }).catch(() => {});

  $('#story-author-avatar').outerHTML = avatarBlock({ title: group.user.displayName, avatarUrl: group.user.avatarUrl, avatarColor: group.user.avatarColor })
    .replace('avatar"', 'avatar" id="story-author-avatar"');
  $('#story-author-name').innerHTML = nameWithPremium(group.user.displayName, group.user.premium);
  $('#story-time').textContent = fmtTime(story.createdAt);
  $('#story-delete-btn').classList.toggle('hidden', !story.mine);

  const progressRow = $('#story-progress-row');
  progressRow.innerHTML = group.stories.map((s, i) =>
    `<div class="seg ${i < storyIdx ? 'done' : ''}" data-i="${i}"><div class="fill"></div></div>`
  ).join('');

  const mediaWrap = $('#story-media-wrap');
  mediaWrap.innerHTML = '';
  if (story.type === 'photo') {
    const img = document.createElement('img');
    img.src = story.fileUrl;
    mediaWrap.appendChild(img);
    startStoryProgress(5000);
  } else {
    const video = document.createElement('video');
    video.src = story.fileUrl;
    video.playsInline = true;
    video.onloadedmetadata = () => startStoryProgress((video.duration || 5) * 1000);
    video.onended = () => advanceGroup(1);
    mediaWrap.appendChild(video);
    video.play().catch(() => {
      // Автовоспроизведение со звуком заблокировано браузером — пробуем без звука
      video.muted = true;
      video.play().catch(() => {});
    });
  }
}

function startStoryProgress(duration) {
  storyTimerDuration = duration;
  storyTimerStart = Date.now();
  const seg = document.querySelector(`.seg[data-i="${storyIdx}"] .fill`);
  const tick = () => {
    const pct = Math.min(100, ((Date.now() - storyTimerStart) / storyTimerDuration) * 100);
    if (seg) seg.style.width = pct + '%';
    if (pct >= 100) { advanceGroup(1); return; }
    storyTimer = setTimeout(tick, 60);
  };
  clearTimeout(storyTimer);
  tick();
}

function advanceGroup(dir) {
  clearTimeout(storyTimer);
  const group = storyGroups[storyGroupIdx];
  if (!group) return closeStoryViewer();
  storyIdx += dir;
  if (storyIdx < 0) {
    storyGroupIdx -= 1;
    if (storyGroupIdx < 0) return closeStoryViewer();
    storyIdx = Math.max(0, (storyGroups[storyGroupIdx]?.stories.length || 1) - 1);
    playCurrentStory();
  } else if (storyIdx >= group.stories.length) {
    storyGroupIdx += 1;
    storyIdx = 0;
    if (storyGroupIdx >= storyGroups.length) return closeStoryViewer();
    playCurrentStory();
  } else {
    playCurrentStory();
  }
}

function closeStoryViewer() {
  clearTimeout(storyTimer);
  $('#story-viewer').classList.add('hidden');
  $('#story-media-wrap').innerHTML = '';
  loadStories();
}

$('#story-close-btn').onclick = closeStoryViewer;
$('#story-nav-prev').onclick = () => advanceGroup(-1);
$('#story-nav-next').onclick = () => advanceGroup(1);
$('#story-delete-btn').onclick = async () => {
  const story = storyGroups[storyGroupIdx]?.stories[storyIdx];
  if (!story || !confirm('Удалить историю?')) return;
  await api('/stories/' + story.id, { method: 'DELETE' });
  closeStoryViewer();
};

// ================== Вложения (фото/видео/документы до 2 ГБ) ==================
$('#attach-btn').onclick = () => $('#file-input').click();
$('#file-input').onchange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  await uploadAndSend(file);
  e.target.value = '';
};

async function uploadAndSend(file, forcedType) {
  const form = new FormData();
  form.append('file', file);
  const res = await fetch('/api/upload', { method: 'POST', headers: { Authorization: 'Bearer ' + token }, body: form });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.error || 'Не удалось загрузить файл');
    return;
  }
  const data = await res.json();
  let type = forcedType;
  if (!type) {
    if (data.mime.startsWith('image/')) type = 'photo';
    else if (data.mime.startsWith('video/')) type = 'video';
    else if (data.mime.startsWith('audio/')) type = 'voice';
    else type = 'file';
  }
  sendMessage({ type, fileUrl: data.url, fileName: data.name, fileSize: data.size });
}

// ================== Голосовые и видеосообщения (кружки) ==================
$('#record-voice-btn').onclick = () => toggleRecording('audio');
$('#record-video-btn').onclick = () => toggleRecording('video_note');

async function toggleRecording(kind) {
  const btn = kind === 'audio' ? $('#record-voice-btn') : $('#record-video-btn');
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
    return;
  }
  try {
    const constraints = kind === 'audio' ? { audio: true } : { audio: true, video: { width: 320, height: 320 } };
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    recordedChunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = (e) => recordedChunks.push(e.data);
    mediaRecorder.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      btn.classList.remove('recording');
      const blob = new Blob(recordedChunks, { type: kind === 'audio' ? 'audio/webm' : 'video/webm' });
      const ext = kind === 'audio' ? 'webm' : 'webm';
      const file = new File([blob], `${kind}-${Date.now()}.${ext}`, { type: blob.type });
      await uploadAndSend(file, kind === 'audio' ? 'voice' : 'video_note');
    };
    mediaRecorder.start();
    btn.classList.add('recording');
  } catch (e) {
    alert('Нет доступа к микрофону/камере: ' + e.message);
  }
}

// ================== Геопозиция ==================
$('#location-btn').onclick = () => {
  if (!navigator.geolocation) return alert('Геолокация не поддерживается браузером');
  navigator.geolocation.getCurrentPosition(
    (pos) => sendMessage({ type: 'location', lat: pos.coords.latitude, lng: pos.coords.longitude, isLive: false }),
    (err) => alert('Не удалось получить геопозицию: ' + err.message)
  );
};

$('#live-location-btn').onclick = () => {
  if (liveLocationWatchId !== null) {
    navigator.geolocation.clearWatch(liveLocationWatchId);
    liveLocationWatchId = null;
    liveLocationMessageId = null;
    $('#live-location-btn').classList.remove('recording');
    return;
  }
  navigator.geolocation.getCurrentPosition((pos) => {
    const payload = { type: 'location', lat: pos.coords.latitude, lng: pos.coords.longitude, isLive: true, chatId: currentChatId, silent: false, replyTo: null };
    socket.emit('message:send', payload, (msg) => {
      liveLocationMessageId = msg.id;
      $('#live-location-btn').classList.add('recording');
      liveLocationWatchId = navigator.geolocation.watchPosition((p) => {
        socket.emit('location:live-update', {
          chatId: currentChatId, lat: p.coords.latitude, lng: p.coords.longitude, messageId: liveLocationMessageId,
        });
      });
    });
  });
};

// ================== Инлайн-бот @gif ==================
let gifDebounce = null;
function handleInlineGifTrigger() {
  const match = textInput.value.match(/@gif\s+(.+)$/i);
  if (!match) { $('#gif-panel').classList.add('hidden'); return; }
  clearTimeout(gifDebounce);
  gifDebounce = setTimeout(async () => {
    const q = match[1];
    const results = await fetch('/api/inline/gif?q=' + encodeURIComponent(q)).then((r) => r.json());
    const panel = $('#gif-panel');
    panel.innerHTML = '';
    results.forEach((g) => {
      const img = document.createElement('img');
      img.src = g.preview;
      img.onclick = () => {
        sendMessage({ type: 'photo', fileUrl: g.url, text: '' });
        textInput.value = '';
        panel.classList.add('hidden');
      };
      panel.appendChild(img);
    });
    panel.classList.toggle('hidden', results.length === 0);
  }, 350);
}

// ================== Звонки (WebRTC) ==================
$('#call-audio-btn').onclick = () => startCall('audio');
$('#call-video-btn').onclick = () => startCall('video');
$('#hangup-btn').onclick = hangup;
$('#screen-share-btn').onclick = toggleScreenShare;
$('#accept-call-btn').onclick = acceptIncomingCall;
$('#reject-call-btn').onclick = () => {
  $('#incoming-call').classList.add('hidden');
  pendingIncomingCall = null;
  pendingOffer = null;
};

let pendingIncomingCall = null;
let pendingOffer = null; // offer может прийти раньше, чем пользователь нажмёт "Принять"

async function startCall(callType) {
  if (!currentChatId) return;
  currentCallChatId = currentChatId;
  localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: callType === 'video' });
  showCallModal();
  $('#local-video').srcObject = localStream;

  pc = new RTCPeerConnection(ICE_SERVERS);
  localStream.getTracks().forEach((t) => pc.addTrack(t, localStream));
  pc.ontrack = (e) => { $('#remote-video').srcObject = e.streams[0]; };
  pc.onicecandidate = (e) => { if (e.candidate) socket.emit('call:ice-candidate', { chatId: currentCallChatId, candidate: e.candidate }); };

  socket.emit('call:invite', { chatId: currentCallChatId, callType });
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  socket.emit('call:offer', { chatId: currentCallChatId, offer });
}

function onCallIncoming({ chatId, callType, fromUserId }) {
  pendingIncomingCall = { chatId, callType };
  $('#incoming-call-text').textContent = `Входящий ${callType === 'video' ? 'видео' : 'аудио'}звонок…`;
  $('#incoming-call').classList.remove('hidden');
}

async function acceptIncomingCall() {
  if (!pendingIncomingCall) return;
  currentCallChatId = pendingIncomingCall.chatId;
  localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: pendingIncomingCall.callType === 'video' });
  showCallModal();
  $('#local-video').srcObject = localStream;

  pc = new RTCPeerConnection(ICE_SERVERS);
  localStream.getTracks().forEach((t) => pc.addTrack(t, localStream));
  pc.ontrack = (e) => { $('#remote-video').srcObject = e.streams[0]; };
  pc.onicecandidate = (e) => { if (e.candidate) socket.emit('call:ice-candidate', { chatId: currentCallChatId, candidate: e.candidate }); };

  $('#incoming-call').classList.add('hidden');

  // Если offer уже успел прийти до нажатия "Принять" — обрабатываем его сейчас
  if (pendingOffer && pendingOffer.chatId === currentCallChatId) {
    const offer = pendingOffer.offer;
    pendingOffer = null;
    await applyOffer(currentCallChatId, offer);
  }
  pendingIncomingCall = null;
}

async function onCallOffer({ chatId, offer }) {
  if (!pc || chatId !== currentCallChatId) {
    // Звонок ещё не принят — запоминаем offer и применим его после нажатия "Принять"
    pendingOffer = { chatId, offer };
    return;
  }
  await applyOffer(chatId, offer);
}

async function applyOffer(chatId, offer) {
  await pc.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  socket.emit('call:answer', { chatId, answer });
}

async function onCallAnswer({ answer }) {
  if (!pc) return;
  await pc.setRemoteDescription(new RTCSessionDescription(answer));
}

async function onRemoteIceCandidate({ candidate }) {
  if (!pc) return;
  try { await pc.addIceCandidate(candidate); } catch (e) {}
}

function onCallEndedRemote() {
  closeCall();
}

function showCallModal() { $('#call-modal').classList.remove('hidden'); }

function hangup() {
  if (currentCallChatId) socket.emit('call:end', { chatId: currentCallChatId });
  closeCall();
}

function closeCall() {
  if (pc) { pc.close(); pc = null; }
  if (localStream) { localStream.getTracks().forEach((t) => t.stop()); localStream = null; }
  $('#call-modal').classList.add('hidden');
  currentCallChatId = null;
  screenTrackSender = null;
}

async function toggleScreenShare() {
  if (!pc) return;
  try {
    const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    const screenTrack = screenStream.getVideoTracks()[0];
    const sender = pc.getSenders().find((s) => s.track && s.track.kind === 'video');
    if (sender) {
      await sender.replaceTrack(screenTrack);
      screenTrackSender = sender;
      screenTrack.onended = async () => {
        const camTrack = localStream.getVideoTracks()[0];
        if (camTrack && sender) await sender.replaceTrack(camTrack);
      };
    }
  } catch (e) {
    // пользователь отменил выбор экрана
  }
}

